


OBS
  BEM = Block Element Modifier
        https://toplearn.com/c/xGjr

  Block__Element--Modifier:

    class="form__input"
    class="form__submit form__submit--disabled"
    class="block block--mod"


if you want to write persian 
    <html lang="fa" dir="rtl">


1- animate.style:
        https://animate.style/

2- Font Awesome:
        https://fontawesome.com/start

3- shortcut icon:
        <link rel="shortcut icon" href="images/pineapple.jpg">